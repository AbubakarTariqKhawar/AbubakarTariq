<?php
define("base_url","http://localhost/AbubakarTariq_Restaurante/");
?>