
<div class="container-lg" style="padding-top: 150px; text-align: center;">
  <img src="<?=base_url.'assets/icons/logobig.png'?>" height="250px">
</div>

<div class="container-lg" style="padding-top: 30px; text-align: center; ">

  
  <h2><b>Contact Us</b></h2>
  <br/>
  <h3><b>Info</b></h3>
  <p style=" font-size: 22px;">
    You can contact:<br/>
    Email: pizzaabu@gmail.com.<br/>
    Phone: 631744689.<br/>
    Web: https://abubakartariq.bernat2023.tk/p2 <br/>
  </p>
  <br/><br/>


</div>


