<div style="float: left; width: 100%; ">
<footer class="mt-5 bg-dark text-light" >
    <nav class="navbar navbar-expand-lg ">
      <div class="container-lg d-flex justify-content-between">
        <div class="d-none d-md-block">
            <a href="https://facebook.com" target="_blank"><img src="<?=base_url.'assets/images/fb.svg'?>" alt="" height="48" width="48"></a>
            <a href="https://twitter.com" target="_blank"><img src="<?=base_url.'assets/images/tw.webp'?>" alt="" height="37" width="37"></a>
            <a href="https://instagram.com" target="_blank"><img src="<?=base_url.'assets/images/in.webp'?>" alt="" height="35" width="35" style="margin-left: 5px;"></a>
        </div>
        <div >
            <a href="<?=base_url.'pizza/index'?>"><img src="<?=base_url.'assets/images/logof2.svg'?>" alt="" height="100"></a>
        </div>
        <div >
            <a href="<?=base_url.'pizza/privacy'?>" style="color: white;">Privacy policies</a>
        </div>
      </div>
    </nav>
</footer>
</div>

</body>
<?php


?>

</html>