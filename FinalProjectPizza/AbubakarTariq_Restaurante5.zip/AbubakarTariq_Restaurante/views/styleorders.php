<style>
      table, th, td, tr{border: 1px solid black; border-collapse: collapse;}
      table {width: 1000px; margin:auto;}
      * {font-family: arial; text-align:center;}
</style>