<?php 
    /*$id_User = $_SESSION['user_id'];
    $admin = $_SESSION['user_admin'];


    $allOrders = '';

    if($admin == 1){
      $allOrders = QUERY::getAllOrder();
      var_dump( $allOrders);
    }else{

    }
    

*/
    
?>